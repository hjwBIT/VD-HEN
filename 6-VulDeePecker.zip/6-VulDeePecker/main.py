#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    ** description **
@scripts: VD - main.py
@author: cct
@time: 11/04/19
"""


def func():
    """description
    1. Parameters：
    2. Returns:
    3. Notes:
    """
    pass


if __name__ == '__main__':
    print('hello?')