# coding:utf-8

# 模块功能：word2vec预训练

# 导入模块
import os
import csv
import collections
import math
import random
import pickle
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE

# 日志等级
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"

# 配置参数
vocabulary_size = 5000  # 词汇表尺寸

# 训练参数
batch_size = 128         # 训练样本的批次大小
embedding_size = 13      # 单词转化为稠密词向量的维度
skip_window = 1          # 单词可以联系到的最远距离
num_skips = 2            # 每个目标单词提取的样本数
epoch_num = 150000       # 迭代次数

# 验证参数
valid_size = 16          # 验证的单词数
valid_window = 100       # 验证单词只从频度最高的前valid_window个单词中进行抽取
valid_examples = np.random.choice(valid_window, valid_size, replace=False)
num_sampled = 128        # 训练时用于做负样本的噪声单词数量


# load_from_csv
# 函数功能：加载csv文件至列表
def load_from_csv(csv_file):
    # 初始化
    load_list = []

    # 逐行读取csv文件
    for line in csv.reader(csv_file):
        load_list.append(line[0])  # line的类型为list

    # 返回列表
    return load_list


# load_corpus
# 函数功能：加载语料库
def load_corpus():
    # 文件路径
    file_dir = "./dataset/"

    # 文件名称
    file_name = "corpus.csv"

    # 打开文件
    csv_file = open(file_dir + file_name)

    # 加载语料库
    corpus = load_from_csv(csv_file)

    # 关闭文件
    csv_file.close()

    # 打印状态
    print("语料库加载完毕..")

    # 返回语料库
    return corpus


# 加载语料库
corpus = load_corpus()


# build_dataset
# 函数功能：构建word2vec数据集
def build_dataset(corpus):
    count = [["UNK", -1]]
    count.extend(collections.Counter(corpus).most_common(vocabulary_size-1))
    dictionary = {}  # 存储<token，编号>的字典
    for word, _ in count:
        dictionary[word] = len(dictionary)  # 对所有词进行编码
    data = []        # 用于保存原始语料的编码形式
    unk_count = 0    # 统计top以外单词个数
    for word in corpus:
        if word in dictionary:
            index = dictionary[word]
        else:
            index = 0
            unk_count = unk_count + 1
        data.append(index)
    count[0][1] = unk_count  # 更新UNK计数
    reverse_dictionary = dict(zip(dictionary.values(), dictionary.keys()))  # 存储<编号，token>的字典
    print(reverse_dictionary)
    print(len(dictionary))
    print(len(reverse_dictionary))
    return data, count, dictionary, reverse_dictionary


# 生成数据集
data, count, dictionary, reverse_dictionary = build_dataset(corpus)
del corpus


# generate_batch
# 函数功能：生成word2vec的训练样本，使用skip-gram模式
data_index = 0
def generate_batch(batch_size, num_skips, skip_window):
    # batch_size：每个训练批次的数据量
    # num_skips：每个单词生成的样本数量
    # skip_window：单词最远可以联系的距离
    # return：返回每个批次的样本以及对应的标签
    global data_index
    assert batch_size % num_skips == 0   # 约束
    assert num_skips <= skip_window * 2  # 约束

    # 初始化
    batch = np.ndarray(shape=batch_size, dtype=np.int32)        # 创建一个batch_size大小的数组，数据类型为int32，数值随机
    labels = np.ndarray(shape=(batch_size, 1), dtype=np.int32)  # 数据维度为[batch_size, 1]
    span = 2 * skip_window + 1                                  # 入队的长度
    buffer = collections.deque(maxlen=span)                     # 创建双向队列，最大长度为span

    # 对双向队列填入初始值
    for _ in range(span):
        buffer.append(data[data_index])
        data_index = (data_index+1) % len(data)

    # 进入第一层循环，i表示第几次进入双向队列
    for i in range(batch_size // num_skips):
        target = skip_window           # 定义buffer中的第skip_window个单词是目标
        targets_avoid = [skip_window]  # 定义生成样本时需要避免的单词
        # 进入第二层循环，每次循环对一个语境单词生成样本
        for j in range(num_skips):
            while target in targets_avoid:
                target = random.randint(0, span-1)
            targets_avoid.append(target)
            batch[i * num_skips + j] = buffer[skip_window]  # 目标词汇
            labels[i * num_skips + j, 0] = buffer[target]   # 语境词汇
        buffer.append(data[data_index])
        data_index = (data_index+1) % len(data)

    # 返回样本及标签
    return batch, labels


# 显示一批样本及标签，检查是否为SG模式
batch, labels = generate_batch(8, 2, 1)
for i in range(8):
    print("目标单词：" + reverse_dictionary[batch[i]] + "对应编号为：".center(20) + str(batch[i]) + " 对应的语境单词为: ".ljust(20)
          + reverse_dictionary[labels[i, 0]] + " 编号为", labels[i, 0])


# 定义Skip-Gram Word2vec的网络结构
graph = tf.Graph()
with graph.as_default():
    train_inputs = tf.placeholder(tf.int32, [batch_size])
    train_labels = tf.placeholder(tf.int32, [batch_size, 1])
    valid_dataset = tf.constant(valid_examples, tf.int32)

    # 选择运行的device为CPU
    with tf.device("/cpu:0"):
        # 单词表长度为vocabulary_size，嵌入长度为embedding_size，随机采样(-1,1)范围的浮点数
        embeddings = tf.Variable(tf.random_uniform([vocabulary_size, embedding_size], -1.0, 1.0))
        # 使用tf.nn.embedding_lookup函数查找train_inputs对应的向量embed
        embed = tf.nn.embedding_lookup(embeddings, train_inputs)

        # 优化目标
        nce_weights = tf.Variable(
            tf.truncated_normal([vocabulary_size, embedding_size], stddev=1.0 / math.sqrt(embedding_size)))
        nce_biases = tf.Variable(tf.zeros([vocabulary_size]))

        # 计算学习出的embedding在训练数据集上的loss，并使用tf.reduce_mean()函数进行汇总
        loss = tf.reduce_mean(tf.nn.nce_loss(
            weights=nce_weights,
            biases=nce_biases,
            labels=train_labels,
            inputs=embed,
            num_sampled=num_sampled,
            num_classes=vocabulary_size
        ))

        # 定义优化器为SGD，且学习率设置为0.5
        # 计算嵌入向量embeddings的L2范数norm，并计算出标准化后的normalized_embeddings
        optimizer = tf.train.GradientDescentOptimizer(0.5).minimize(loss)
        norm = tf.sqrt(tf.reduce_sum(tf.square(embeddings), 1, keep_dims=True))  # 嵌入向量的L2范数
        normalized_embeddings = embeddings / norm  # 标准化embeddings
        valid_embeddings = tf.nn.embedding_lookup(normalized_embeddings, valid_dataset)  # 查询验证单词的嵌入向量
        # 计算验证单词的嵌入向量与词汇表中所有单词的相似性
        similarity = tf.matmul(
            valid_embeddings, normalized_embeddings, transpose_b=True
        )


# 启动训练
num_steps = epoch_num  # 迭代次数
with tf.Session(graph=graph) as session:
    tf.initialize_all_variables().run()  # 启动参数的初始化
    print("初始化完成..")
    average_loss = 0  # 计算误差

    # 开始迭代训练
    for step in range(num_steps):
        batch_inputs, batch_labels = generate_batch(batch_size, num_skips, skip_window)  # 调用生成训练数据函数生成一组batch和label
        feed_dict = {train_inputs: batch_inputs, train_labels: batch_labels}  # 待填充的数据
        # 启动会话，运行优化器optimizer和损失计算函数，并填充数据
        optimizer_trained, loss_val = session.run([optimizer, loss], feed_dict=feed_dict)
        average_loss += loss_val  # 统计NCE损失

        # 每2000次计算损失并显示
        if step % 2000 == 0:
            if step > 0:
                average_loss /= 2000
            print("第{}轮迭代后的损失为：{}".format(step, average_loss))
            average_loss = 0

        # 每10000次迭代，计算一次验证单词与全部单词的相似度，并将与验证单词最相似的前8个单词呈现出来
        if step % 10000 == 0:
            sim = similarity.eval()  # 计算向量
            for i in range(valid_size):
                valid_word = reverse_dictionary[valid_examples[i]]   # 得到对应的验证单词
                top_k = 8
                nearest = (-sim[i, :]).argsort()[1:top_k+1]          # 计算每一个验证单词相似度最接近的前8个单词
                log_str = "与单词 {} 最相似的： ".format(str(valid_word))
                for k in range(top_k):
                    if nearest[k] in reverse_dictionary:
                        close_word = reverse_dictionary[nearest[k]]  # 相似度高的单词
                        log_str = "%s %s, " % (log_str, close_word)
                print(log_str)
    final_embeddings = normalized_embeddings.eval()


# 保存结果
# save_obj
# 函数功能：保存对象到pkl文件
def save_obj(obj, file_path):
    with open(file_path, 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)


# 保存dictionary
save_obj(dictionary, "./dataset/word2vec/dictionary.pkl")
print("dictionary保存完毕..")

# 保存reverse_dictionary
save_obj(reverse_dictionary, "./dataset/word2vec/reverse_dictionary.pkl")
print("reverse_dictionary保存完毕")

# 保存final_embeddings
np.save("./dataset/word2vec/word2vec_embs.npy", final_embeddings)
print("final_embeddings保存完毕")


# plot_with_labels
# 函数功能：可视化
def plot_with_labels(low_dim_embs, labels, filename="./dataset/word2vec/word2vec.png"):
    assert low_dim_embs.shape[0] >= len(labels), "标签数超过了嵌入向量的个数.."

    plt.figure(figsize=(20, 20))
    for i, label in enumerate(labels):
        x, y = low_dim_embs[i, :]
        plt.scatter(x, y)
        plt.annotate(
            label,
            xy=(x, y),
            xytext=(5, 2),
            textcoords="offset points",
            ha="right",
            va="bottom"
        )
    plt.savefig(filename)


# 可视化显示
tsne = TSNE(perplexity=30, n_components=2, init="pca", n_iter=5000)  # 降维
plot_only = 100
low_dim_embs = tsne.fit_transform(final_embeddings[:plot_only, :])
Labels = [reverse_dictionary[i] for i in range(plot_only)]
plot_with_labels(low_dim_embs, Labels)
print("TSNE保存完毕")
