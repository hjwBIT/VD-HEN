import tensorflow as tf
import numpy as np


# 加载预训练结果
# load_obj
# 函数功能：加载对象
def load_obj(file_path):
    with open(file_path, 'rb') as f:
        return pickle.load(f)


# 预训练词向量
final_embeddings = np.load("./dataset/word2vec/word2vec_embs.npy")


class BiLSTM(object):
    """
    A BiLSTM for text classification.
    """
    def __init__(
      self, sequence_length, num_classes):
        # Variable
        self.hidden_dim = 64  # 输出隐层维度

        # Placeholders for batch_size, input, output and dropout
        self.actual_batch_size = tf.placeholder(tf.int32, name="actual_batch_size")
        self.input_x = tf.placeholder(tf.int32, [None, sequence_length, 9], name="input_x")
        self.input_y = tf.placeholder(tf.float32, [None, num_classes], name="input_y")
        self.dropout_keep_prob = tf.placeholder(tf.float32, name="dropout_keep_prob")

        # Embedding layer
        with tf.device('/cpu:0'), tf.name_scope("embedding"):
            self.g_embeddings = tf.get_variable(name="W", shape=final_embeddings.shape,
                                                initializer=tf.constant_initializer(final_embeddings), trainable=False)
            self.encoding = tf.nn.embedding_lookup(self.g_embeddings, self.input_x)
            split_list = tf.split(value=self.encoding, axis=2, num_or_size_splits=9)  # 沿第2维切片
            self.inputs = split_list[0]
            for i in range(1, len(split_list)):
                self.inputs = tf.concat([self.inputs, split_list[i]], 3)  # 沿第3维连接（instruction2vec)
            self.embedded_chars = tf.reduce_max(self.inputs, axis=2)  # 将第2维降维

        # RNN layer
        with tf.name_scope("rnn"):
            cell_bw = tf.contrib.rnn.BasicLSTMCell(self.hidden_dim, forget_bias=1.0, state_is_tuple=True)
            cell_bw = tf.contrib.rnn.DropoutWrapper(cell_bw, output_keep_prob=self.dropout_keep_prob)
            cell_fw = tf.contrib.rnn.BasicLSTMCell(self.hidden_dim, forget_bias=1.0, state_is_tuple=True)
            cell_fw = tf.contrib.rnn.DropoutWrapper(cell_fw, output_keep_prob=self.dropout_keep_prob)

        # Output layer
        with tf.name_scope("output"):
            self.outputs, self.states = tf.nn.bidirectional_dynamic_rnn(cell_bw, cell_fw, self.embedded_chars, dtype=tf.float32)
            self.outputs = tf.reshape(self.outputs, shape=[-1, sequence_length, self.hidden_dim])
            self.outputs = tf.transpose(self.outputs, perm=[1, 0, 2])
            self.outputs = tf.reduce_mean(self.outputs, 0)
            self.outputs = self.outputs[:self.actual_batch_size] + self.outputs[self.actual_batch_size:]
            self.logits = tf.layers.dense(self.outputs, 2, name="logits")
            self.prob = tf.nn.softmax(self.logits, name="softmax_output")
            self.predictions = tf.argmax(self.prob, 1, name="predictions")

        # Calculate mean cross-entropy loss
        with tf.name_scope("train"):
            losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.input_y)
            self.loss = tf.reduce_mean(losses)

        # Accuracy
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.input_y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")

        # TP FP TN FN
        with tf.name_scope("TP_FP_TN_FN"):
            self.TP = tf.metrics.true_positives(labels=tf.argmax(self.input_y, 1), predictions=self.predictions)
            self.FP = tf.metrics.false_positives(labels=tf.argmax(self.input_y, 1), predictions=self.predictions)
            self.TN = tf.metrics.true_negatives(labels=tf.argmax(self.input_y, 1), predictions=self.predictions)
            self.FN = tf.metrics.false_negatives(labels=tf.argmax(self.input_y, 1), predictions=self.predictions)
