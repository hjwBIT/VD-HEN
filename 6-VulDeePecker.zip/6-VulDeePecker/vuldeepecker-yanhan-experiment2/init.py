# coding:utf-8

# 模块功能：加载数据集（分解结构）、加载预训练结果

# 导入模块
import os
import scanner

# 宏
BAD = 0   # 标签
GOOD = 1  # 标签
SEQUENCE = scanner.SEQUENCE    # 序列分解结构（函数列表-函数-token序列）
HIERARCHY = scanner.HIERARCHY  # 层次分解结构（函数列表-函数-句子-token序列）
SPLIT = "/**********SPLIT**********/\n"


# get_file_path
# 函数功能：返回数据集文件路径
def get_file_path(LABEL):
    # 初始化
    file_dir = "./dataset/"
    bad_file_name = ""
    good_file_name = ""

    # 获取数据集目录下所有文件及目录
    file_or_dirs = os.listdir(file_dir)

    # 获取源文件
    for src_file in file_or_dirs:
        if "bad" in src_file:
            bad_file_name = src_file
        elif "good" in src_file:
            good_file_name = src_file
        else:
            continue

    # 返回数据集文件路径
    if LABEL is BAD and bad_file_name != "":
        return file_dir+bad_file_name
    if LABEL is GOOD and bad_file_name != "":
        return file_dir+good_file_name

    # 异常
    print("获取失败..")


# load_file
# 函数功能：加载数据集文件
def load_file(file_path):
    # 打开文件
    f = open(file_path, "r")  # 源文件，只读

    # 读取文件全部内容到内存
    content = f.read()

    # 关闭文件
    f.close()

    # 返回数据
    return content


# get_func_list
# 函数功能：获取函数列表（每个函数是数据集的一条记录）
def get_func_list(content):
    # 初始化
    tar_func_list = []

    # 分隔函数
    src_func_list = content.split(SPLIT)
    src_func_list.pop(0)

    # 取出数据
    for func in src_func_list:
        func = func.strip()
        tar_func_list.append(func)

    # 返回函数列表
    return tar_func_list


# load_dataset
# 函数功能：返回样本
def load_dataset(LABEL, STRUCTURE, STOP_LIST):
    # 数据集名称
    file_path = get_file_path(LABEL)

    # 加载数据集文件
    content = load_file(file_path)

    # 提取数据
    func_list = get_func_list(content)

    # 打印状态
    print("数据集文件" + file_path + "加载完毕..")

    # 分解结构
    func_list_decomposed = scanner.scan_func_list(func_list, STRUCTURE, STOP_LIST)

    # 打印状态
    if LABEL == BAD:
        print("正样本加载完毕..")
    elif LABEL == GOOD:
        print("负样本加载完毕..")
    else:
        print("数据集加载异常..")

    # 返回数据
    return func_list_decomposed
