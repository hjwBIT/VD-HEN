# coding:utf-8

# 模块功能：指令分割；词法分析（序列化）；去停用词

# 宏
SEQUENCE = 0   # 序列分解结构
HIERARCHY = 1  # 层次分解结构
STOP = [""]                                            # 停用词，由scan_func_list参数指定
JUMP_TYPE = ["short"]                                  # 跳转类型
KEY_WORD = ["+", "-", "*", "[", "]"]                   # 关键词
OPERAND_LEN = ["byte ptr", "dword ptr", "word ptr"]    # 操作类型


# lexical_analysis
# 函数功能：词法分析（序列化）
def lexical_analysis(instruction):
    # 初始化
    inst_decomposed = []     # 保存指令中的token
    rest_part = instruction  # 待分析的部分

    # 词法分析
    # 操作码
    opcode = rest_part.split(" ")[0]
    inst_decomposed.append(opcode)
    rest_part = rest_part.lstrip(opcode).strip()

    # JUMP_TYPE
    for jump_type in JUMP_TYPE:
        if rest_part.startswith(jump_type):
            rest_part = rest_part.lstrip(jump_type).strip()
            break

    # OPERAND_LEN
    for op_len in OPERAND_LEN:
        if rest_part.startswith(op_len):
            rest_part = rest_part.lstrip(op_len).strip()
            break

    # 操作数
    operands = rest_part.split(",")

    # 补全操作数个数
    for i in range(len(operands), 2):
        operands.append("0")

    # 提取token
    for operand in operands:
        # 初始化
        count = 0               # 提取token的个数
        key_word_position = []  # 保存关键字出现的位置
        key_word_len = {}       # 保存<关键字位置，关键字长度>的字典

        # 计算关键字出现的位置
        for key_word in KEY_WORD:
            key_index = operand.find(key_word)                # 获取索引
            key_word_position.append(key_index)               # 添加索引
            key_word_len[key_index] = len(key_word)           # 记录长度
            key_word_position = list(set(key_word_position))  # 列表去重
            key_word_position.sort()                          # 列表排序

        # 根据关键字/符号出现的位置分词
        start = 0
        end = 0
        operand_len = len(operand)
        while start < operand_len:
            # 获取token
            if start in key_word_position:
                end = start + key_word_len[start]  # 计算end位置
            else:
                is_find = False                    # 标志位，用于处理结尾
                for pos in key_word_position:
                    if pos > start:
                        end = pos                  # 计算end位置
                        is_find = True
                        break
                if not is_find:
                    end = operand_len
            token = operand[start:end].strip()
            # 存储token
            if token is not "" and token not in KEY_WORD:
                inst_decomposed.append(token)
                count = count + 1
            start = end
        # 不足4个token则用"0"补齐
        for i in range(count, 4):
            inst_decomposed.append("0")

    # 返回语句的分解结构
    return inst_decomposed


# scan_func
# 函数功能：获取func的分解结构
def scan_func(func, STRUCTURE):
    # 初始化
    func_decomposed = []

    # 句子分割
    instructions = func.split("\n")  # 保存程序的每条语句的列表

    # 词分割
    for instruction in instructions:
        inst_decomposed = lexical_analysis(instruction)      # 词法分析
        if len(inst_decomposed) > 0:                         # 删除空行
            if STRUCTURE == HIERARCHY:                       # 层次结构
                func_decomposed.append(inst_decomposed)
            elif STRUCTURE == SEQUENCE:                      # 序列结构
                func_decomposed = func_decomposed + inst_decomposed

    # 返回func的分解结构
    return func_decomposed


# scan_func_list
# 函数功能：获取func_list的分解结构
def scan_func_list(func_list, STRUCTURE, STOP_LIST):
    # 初始化
    func_list_decomposed = []
    global STOP
    STOP = STOP_LIST

    # 遍历扫描
    for func in func_list:
        func_list_decomposed.append(scan_func(func, STRUCTURE))

    # 打印状态
    print("分解结构加载完毕..")

    # 返回func_list的分解结构
    return func_list_decomposed
