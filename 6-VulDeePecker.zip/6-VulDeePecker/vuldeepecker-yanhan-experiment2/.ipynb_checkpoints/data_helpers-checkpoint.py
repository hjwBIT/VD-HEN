import numpy as np
import re
import init
import pickle

# 宏
STOP = [""]

# 训练参数
max_seq_len = 150  # 样本的最大长度


# 加载预训练结果
# load_obj
# 函数功能：加载对象
def load_obj(file_path):
    with open(file_path, 'rb') as f:
        return pickle.load(f)


# 存储<token,序号>的字典
dictionary = load_obj("./dataset/word2vec/dictionary.pkl")


# load_data_and_labels
# 函数功能：加载数据集
def load_data_and_labels(positive_data_file, negative_data_file):
    positive_examples = []  # 正样本
    negative_examples = []  # 负样本
    bad_sentences = init.load_dataset(init.BAD, init.HIERARCHY, STOP)  # bad函数
    good_sentences = init.load_dataset(init.GOOD, init.HIERARCHY, STOP)  # good函数

    # 符号数值化
    # bad
    for func in bad_sentences:
        data = []
        for instruction in func:
            data_word = []
            for word in instruction:
                if word in dictionary:
                    index = dictionary[word]
                else:
                    index = dictionary["UNK"]
                data_word.append(index)
            data.append(data_word)
        # 统一长度
        data_len = len(data)
        if data_len > max_seq_len:
            data = data[:max_seq_len]  # 截取
        else:
            for i in range(max_seq_len - data_len):
                data.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
        positive_examples.append(data)

    # good
    for func in good_sentences:
        data = []
        for instruction in func:
            data_word = []
            for word in instruction:
                if word in dictionary:
                    index = dictionary[word]
                else:
                    index = dictionary["UNK"]
                data_word.append(index)
            data.append(data_word)
        # 统一长度
        data_len = len(data)
        if data_len > max_seq_len:
            data = data[:max_seq_len]
        else:
            for i in range(max_seq_len - data_len):
                data.append([0, 0, 0, 0, 0, 0, 0, 0, 0])
        negative_examples.append(data)

    # 组合数据集
    # 第0维：样本的序号
    # 第1维：指令的序号
    # 第2维：指令中元素的序号
    sentences = np.array(positive_examples + negative_examples)

    # 生成标签
    positive_labels = [[0, 1] for _ in positive_examples]
    negative_labels = [[1, 0] for _ in negative_examples]
    labels = np.concatenate([positive_labels, negative_labels], 0)

    return sentences, labels


def batch_iter(data, batch_size, num_epochs, shuffle=True):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int((len(data)-1)/batch_size) + 1
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            yield shuffled_data[start_index:end_index]
