import pandas as pd
import random
import torch
import time
import numpy as np
from gensim.models.word2vec import Word2Vec
from model import BatchProgramClassifier
from torch.autograd import Variable
from torch.utils.data import DataLoader
import os
import sys

HIDDEN_DIM = 100  # 隐藏层维度 100
ENCODE_DIM = 128  # 编码层？维度 128，
# LABELS = 104
LABELS = 2  # 标签种类数量
EPOCHS = 15
BATCH_SIZE = 64
USE_GPU = True

def get_batch(dataset, idx, bs):
    '''
    从 dataset 中 获取 1 batch 数据（ bs 条样本），从 idx 开始
    并将 labels 从 int 型转成 torch.LongTensor 型，为什么呢？ 
    返回：特征集 data，标签集 labels
    '''
    tmp = dataset.iloc[idx: idx+bs]
    data, labels = [], []
    for _, item in tmp.iterrows():
        data.append(item[1])
        # labels.append(item[2]-1)
        labels.append(item[2])
    return data, torch.LongTensor(labels)

def train():
    # root = 'data/'

    # 读数据
    # cwe119_df = pd.read_pickle('data/cwe119_c_all.pkl')
    # cwe119_blocks_df = cwe119_df[['id', 'blocks']][:100]
    cwe119_blocks_df = pd.read_pickle('../data/cwe119_c_100.pkl')
    cwe119_blocks_df_rd = cwe119_blocks_df.sample(frac=1, random_state=1)  # 随机乱序

    # 划分比例
    ratio = '3:1:1'
    total_num = len(cwe119_blocks_df)
    ratios = [int(r) for r in ratio.split(':')]
    train_split = int(ratios[0]/sum(ratios)*total_num)
    val_split = train_split + int(ratios[1]/sum(ratios)*total_num)
    # 划分
    train_data = cwe119_blocks_df_rd.iloc[:train_split] 
    val_data = cwe119_blocks_df_rd.iloc[train_split:val_split] 
    test_data = cwe119_blocks_df_rd.iloc[val_split:]

    # 读词嵌入
    word2vec = Word2Vec.load('data/embedding_128').wv
    embeddings = np.zeros((word2vec.syn0.shape[0] + 1, word2vec.syn0.shape[1]), dtype="float32")
    embeddings[:word2vec.syn0.shape[0]] = word2vec.syn0
    # embeddings 比 wv 多一行（即多一个token）,其值为全 0
    MAX_TOKENS = word2vec.syn0.shape[0]  # token 种类数量
    EMBEDDING_DIM = word2vec.syn0.shape[1]  # 词嵌入的维度，128维
    # 创建模型，传入参数和词嵌入向量
    model = BatchProgramClassifier(EMBEDDING_DIM,HIDDEN_DIM,
                                    MAX_TOKENS+1,ENCODE_DIM,
                                    LABELS,BATCH_SIZE,
                                    USE_GPU, embeddings)
    if USE_GPU:
        model.cuda()  # 转成 gpu 模型

    parameters = model.parameters()  # 参数，
    optimizer = torch.optim.Adamax(parameters)  # 优化器，优化模型的参数
    loss_function = torch.nn.CrossEntropyLoss()  # 目标函数：交叉熵损失

    train_loss_ = []  # 每轮的训练损失
    val_loss_ = []  # 每轮的验证损失
    train_acc_ = []  # 每轮的训练acc
    val_acc_ = []  # 每轮的验证acc
    best_acc = 0.0  # 最高的验证acc，后面没有对它进行更新？
    print('Start training...')
    # training procedure
    best_model = model
    for epoch in range(EPOCHS):  # 每轮
        start_time = time.time()

        total_acc = 0.0
        total_loss = 0.0
        total = 0.0   # 已训练样本的总个数，是否与 i 相等？
        i = 0

        classnum = 9
        target_num = torch.zeros((1,classnum))
        predict_num = torch.zeros((1,classnum))
        acc_num = torch.zeros((1,classnum))

        while i < len(train_data):  # 训练集的每批
            batch = get_batch(train_data, i, BATCH_SIZE)
            i += BATCH_SIZE
            train_inputs, train_labels = batch
            if USE_GPU:  # 使用 gpu 时，将 labels 转成 gpu 张量
                train_inputs, train_labels = train_inputs, train_labels.cuda()

            model.zero_grad()  # 把模型中参数的梯度设为0
            model.batch_size = len(train_labels)  # 为什么不用 BATCH_SIZE ？
            model.hidden = model.init_hidden()  # 后面又不用它，赋值有什么意义？
            output = model(train_inputs)  # 预测结果，二维(64, 2)，即 64 个样本，2 种标签

            loss = loss_function(output, Variable(train_labels)) # 计算损失值
            loss.backward()  # 后向传播、计算梯度，更新参数？loss 是标量。
            optimizer.step()  # 开始优化，更新参数，降低 loss，

            # calc training acc
            _, predicted = torch.max(output.data, 1)  # 返回 output 中每行（样本标签）的最大预测值和最大值的索引
            total_acc += (predicted == train_labels).sum()  # 手动计算查准率
            total += len(train_labels)
            total_loss += loss.item()*len(train_inputs)  # ？

            # 计算 f1
            # correct += predicted.eq(train_labels.data).sum()

            pre_mask = torch.zeros(output.size()).scatter_(1, predicted.cpu().view(-1, 1), 1.)
            predict_num += pre_mask.sum(0)
            tar_mask = torch.zeros(output.size()).scatter_(1, train_labels.data.cpu().view(-1, 1), 1.)
            target_num += tar_mask.sum(0)
            acc_mask = pre_mask*tar_mask
            acc_num += acc_mask.sum(0)
        # 一轮训练结束后
        recall = acc_num/target_num
        precision = acc_num/predict_num
        F1 = 2*recall*precision/(recall+precision)
        accuracy = acc_num.sum(1)/target_num.sum(1)
        #精度调整
        recall = (recall.numpy()[0]*100).round(3)
        precision = (precision.numpy()[0]*100).round(3)
        F1 = (F1.numpy()[0]*100).round(3)
        accuracy = (accuracy.numpy()[0]*100).round(3)
        # 打印格式方便复制
        print('recall'," ".join('%s' % id for id in recall))
        print('precision'," ".join('%s' % id for id in precision))
        print('F1'," ".join('%s' % id for id in F1))
        print('accuracy',accuracy)       

        train_loss_.append(total_loss / total)  # 训练完一轮（所有样本）后的平均损失
        train_acc_.append(total_acc.item() / total)  # 训练完一轮（所有样本）后的平均损失

        # validation epoch
        total_acc = 0.0
        total_loss = 0.0
        total = 0.0
        i = 0
        while i < len(val_data):  # 验证集的每批，代码与训练集的处理大同小异
            batch = get_batch(val_data, i, BATCH_SIZE)
            i += BATCH_SIZE
            val_inputs, val_labels = batch
            if USE_GPU:
                val_inputs, val_labels = val_inputs, val_labels.cuda()

            model.batch_size = len(val_labels)
            model.hidden = model.init_hidden()
            output = model(val_inputs)

            loss = loss_function(output, Variable(val_labels))

            # calc valing acc
            _, predicted = torch.max(output.data, 1)
            total_acc += (predicted == val_labels).sum()
            total += len(val_labels)
            total_loss += loss.item()*len(val_inputs)

        val_loss_.append(total_loss / total)  # 验证集训练完一轮后的平均损失
        val_acc_.append(total_acc.item() / total)  # 验证集训练完一轮后的平均acc
        end_time = time.time()
        if total_acc/total > best_acc:  # 没有对 best_acc 的更新，代码有问题吧
            best_model = model
        print('[Epoch: %3d/%3d] Training Loss: %.4f, Validation Loss: %.4f,'
              ' Training Acc: %.3f, Validation Acc: %.3f, Time Cost: %.3f s'
              % (epoch + 1, EPOCHS, train_loss_[epoch], val_loss_[epoch],
                 train_acc_[epoch], val_acc_[epoch], end_time - start_time))
    
    # 所有轮训练、验证完成后，进行测试
    total_acc = 0.0
    total_loss = 0.0
    total = 0.0
    i = 0
    model = best_model
    while i < len(test_data):
        batch = get_batch(test_data, i, BATCH_SIZE)
        i += BATCH_SIZE
        test_inputs, test_labels = batch
        if USE_GPU:
            test_inputs, test_labels = test_inputs, test_labels.cuda()

        model.batch_size = len(test_labels)
        model.hidden = model.init_hidden()
        output = model(test_inputs)

        loss = loss_function(output, Variable(test_labels))

        _, predicted = torch.max(output.data, 1)
        total_acc += (predicted == test_labels).sum()
        total += len(test_labels)
        total_loss += loss.item() * len(test_inputs)
    print("Testing results(Acc):", total_acc.item() / total)

if __name__ == '__main__':
    train()